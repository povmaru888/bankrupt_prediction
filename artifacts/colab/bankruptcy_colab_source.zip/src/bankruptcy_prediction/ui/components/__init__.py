"""Reusable Streamlit result components."""

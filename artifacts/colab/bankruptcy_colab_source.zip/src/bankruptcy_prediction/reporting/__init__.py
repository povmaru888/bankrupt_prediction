"""Offline model report generation."""

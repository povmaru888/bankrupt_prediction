"""Frozen-model evaluation utilities."""
